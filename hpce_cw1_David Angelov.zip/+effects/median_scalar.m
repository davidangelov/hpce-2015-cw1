function [out]=median_scalar(in)

out = median(in(1:numel(in)));

end

